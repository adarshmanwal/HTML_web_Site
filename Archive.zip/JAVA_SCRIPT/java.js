
$('.second').slick({
    slidesToShow:5,
    slidesToScroll:1,
    dots:true,
    arrows:true,
    autoplay:true,
    autoplaySpeed:2000,
    infinite:true
});





